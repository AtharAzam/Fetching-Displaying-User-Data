import UserView from "@/view/user-view";

const Page = () => {
  return <UserView />;
};

export default Page;
